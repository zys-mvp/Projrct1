﻿#include<iostream>
using namespace std;
#include<stdlib.h>
#define MaxSize 20
bool visit[MaxSize];
typedef struct ArcNode
{
	int info;
	int adjvex;
	ArcNode* nextarc;
}ArcNode;
typedef struct VexNode
{
	char data;
	ArcNode* firstarc;
}VexNode;
typedef struct Graph
{
	VexNode adjlist[MaxSize];
	int VexNum;
	int ArcNum;
}Graph;
void CreateGraph(Graph*& G);
int GetVexOrder(Graph* G, char data);
void InsertGraph(Graph* &G, int begin, int over);
int FirstVex(Graph* G, int v);
int NextVex(Graph* G, int v, int w);
void BFS(Graph* G);
int main() {
	Graph* G;
	CreateGraph(G);
	BFS(G);
	return 0;
}

//获得Vex的次序

int GetVexOrder(Graph* G, char data) {
	for (int i = 0; i < G->VexNum; ++i)
		if (G->adjlist[i].data == data)return i;
	return -1;
}

//插入图

void InsertGraph(Graph*& G, int begin, int over) {
	ArcNode* P = new ArcNode;
	P->adjvex = over;
	P->nextarc = G->adjlist[begin].firstarc;
	G->adjlist[begin].firstarc = P;
}

//第一个Vex

int FirstVex(Graph* G, int v) {
	if (v<0 || v>MaxSize)return-1;
	ArcNode* P = G->adjlist[v].firstarc;
	if (P)return P->adjvex;
	else return -1;
}

//下一个Vex

int NextVex(Graph* G, int v, int m) {
	if (v < 0 || v>MaxSize)return -1;
	if (m<0 || m>MaxSize)return -1;
	ArcNode* P = G->adjlist[v].firstarc;
	while (P && P->adjvex != m)P = P->nextarc;
	if (P->nextarc)return P->nextarc->adjvex;
	else return -1;
}

//建图

void CreateGraph(Graph*& G) {
	G = new Graph;
	cin >> G->VexNum >> G->ArcNum;
	for (int i = 0; i < G->VexNum; ++i) {
		cin >> G->adjlist[i].data;
		G->adjlist[i].firstarc = NULL;
	}
	char x, y;
	int begin, over;
	for (int i = 0; i < G->VexNum; ++i) {
		cin >> x >> y;
		begin = GetVexOrder(G, x);
		over = GetVexOrder(G, y);
		InsertGraph(G, begin, over);
	}
}
void BFS(Graph* G) {
	for (int i = 0; i < G->VexNum; ++i)
		visit[i] = false;
	int Queue[MaxSize];
	int front=0, rear=0;
	for(int i=0;i<G->VexNum;++i)
		if (visit[i] == false) {
			visit[i] = true;
			cout << G->adjlist[i].data << " ";
			rear = (rear + 1) % MaxSize;
			Queue[rear] = i;
			while (front != rear) {
				front = (front + 1) % MaxSize;
				int m = Queue[front];
				for (int w = FirstVex(G, m); w != -1; w = NextVex(G, m, w)) 
					if (!visit[w]) {
						visit[w] = true;
						cout << G->adjlist[w].data << " ";
						rear = (rear + 1) % MaxSize;
						Queue[rear] = w;
					}
			}
		}
}